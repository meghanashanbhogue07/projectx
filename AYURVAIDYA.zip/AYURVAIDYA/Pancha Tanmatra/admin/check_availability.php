<?php 
$conn = mysqli_connect('localhost','root','','ayurvaidya');
require_once("include/config.php");
if(!empty($_POST["email"])) {
	$email= $_POST["email"];
	
		// Prepare the SQL statement with placeholders
$sql = "SELECT email FROM users WHERE email=?";

// Prepare the statement
$stmt = mysqli_prepare($conn, $sql);

// Bind the parameter with the actual value
mysqli_stmt_bind_param($stmt, "s", $email);

// Execute the statement
mysqli_stmt_execute($stmt);

// Fetch the result
$result = mysqli_stmt_get_result($stmt);

// Get the number of rows
$count = mysqli_num_rows($result);
		echo $count;
if($count>0)
{
echo "<span style='color:red'> Email already exists .</span>";
 echo "<script>$('#submit').prop('disabled',true);</script>";
} else{
	
	echo "<span style='color:green'> Email available for Registration .</span>";
 echo "<script>$('#submit').prop('disabled',false);</script>";
}
}


?>
