<html>
write your HTML to Handle this redirect
</html>