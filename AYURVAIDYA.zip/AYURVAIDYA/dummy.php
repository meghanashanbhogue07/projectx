<?Php
require_once('../tcpdf/tcpdf.php');
$pdf = new TCPDF(); 
$pdf->AddPage();
$html='hello';
$pdf->writeHTML($html, true, false, true, false, '');

$pdf->Image('IMG_20230421_201542.jpg',50,50);

$pdf->Output();
?>